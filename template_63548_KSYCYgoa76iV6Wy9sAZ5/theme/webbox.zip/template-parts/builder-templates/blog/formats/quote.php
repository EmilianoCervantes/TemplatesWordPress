<?php
/**
 * Template for displaying audio post format item content
 *
 * @package Webbox
 */

tm_divi_post_format_content();
